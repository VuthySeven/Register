package com.example.register;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends AppCompatActivity {

    EditText firstName, lastName, email, password, confirmPassword;
    Button register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        firstName = findViewById(R.id.firstName);
        lastName = findViewById(R.id.lastName);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        confirmPassword = findViewById(R.id.confirmPassword);

        register = findViewById(R.id.register);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    if(password.getText().toString().equals(confirmPassword.getText().toString())){
                        Intent intent = new Intent(Register.this, MainActivity.class);

                        intent.putExtra("firstName", firstName.getText().toString());
                        intent.putExtra("lastName",  lastName.getText().toString());
                        intent.putExtra("email", email.getText().toString());
                        intent.putExtra("password", password.getText().toString());
                        startActivity(intent);
                    }
                    else{
                        Toast.makeText(Register.this, "The passwords confirmation does not match.", Toast.LENGTH_LONG).show();
                    }
            }
        });
    }
}
