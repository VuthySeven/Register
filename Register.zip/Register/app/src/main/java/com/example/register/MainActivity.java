package com.example.register;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView firstNameTextView, lastNameTextView, emailTextView, passwordTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firstNameTextView = findViewById(R.id.firstName);
        lastNameTextView = findViewById(R.id.lastName);
        emailTextView = findViewById(R.id.email);
        passwordTextView = findViewById(R.id.password);

        Intent intent = getIntent();
        if (intent != null) {
            String firstName = intent.getStringExtra("firstName");
            String lastName = intent.getStringExtra("lastName");
            String email = intent.getStringExtra("email");
            String password = intent.getStringExtra("password");

            firstNameTextView.setText("First Name: " +firstName);
            lastNameTextView.setText("Last Name: " +lastName);
            emailTextView.setText("Email: " +email);
            passwordTextView.setText("Password: " +password);


        }
    }
}
